package com.company;

abstract public class Shape implements Comparable<Shape> {
    public double volume;

    public double getVolume() {
        return volume;
    }
    public Shape(double volume) {
        this.volume = volume;
    }

    @Override
    public int compareTo(Shape o) {
        return Double.compare(o.volume, volume);
    }
}
