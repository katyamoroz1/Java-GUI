package com.company;

public class BagException extends Exception {
    public BagException() {
        super();
    }

    public BagException(String message) {
        super(message);
    }
}
