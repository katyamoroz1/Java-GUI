package com.company;

public class Sphere extends RotationShape {
    public Sphere(double r) {
        super(r, Math.pow(r, 3) * 4  * Math.PI / 3);
    }
}
