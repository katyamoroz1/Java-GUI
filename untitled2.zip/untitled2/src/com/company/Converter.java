package com.company;

public class Converter {
    public static Taper convert(Circle figure) {
       return new Taper(figure.r,5);
    }
}
