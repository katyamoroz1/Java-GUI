package com.company;

public class RotationShape extends Shape {
    public double radius;

    public double getRadius() {
        return radius;
    }

    public RotationShape(double r, double volume) {
        super(volume);
        this.radius = r;
    }
}
