package com.company;

abstract public class Figure {
    public double getArea() {
        return area;
    }
    public Figure (double area) {
        this.area = area;
    }
    public double area;
}
