package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Form form = new Form();
        form.setForm();
        Knapsack k = new Knapsack(10);

        Scanner in = new Scanner(System.in);
//        double r = in.nextDouble();
//        Sphere s = new Sphere(r);

        double radius_taper = in.nextDouble();
        double h = in.nextDouble();
        Taper t = new Taper(radius_taper, h);
        System.out.println(t.getVolume());
        double radius_taper1 = in.nextDouble();
        double h1 = in.nextDouble();
        Taper t1 = new Taper(radius_taper1, h1);
        System.out.println(t1.getVolume());
//        double radius_c = in.nextDouble();
//        double hight = in.nextDouble();
//        Cylinder c = new Cylinder(radius_c, hight);

        try {
            k.add(t);
        } catch (BagException e){
            System.out.println(e.getMessage());
        }
        try {
            k.add(t1);
        } catch (BagException e){
            System.out.println(e.getMessage());
        }
        double r = in.nextDouble();
        Circle c = new Circle(r);
        try {
            k.add(Converter.convert(c));
        } catch (BagException e) {
            System.out.println(e.getMessage());
        }
        k.print();
        System.out.println("ok");
    }
}
